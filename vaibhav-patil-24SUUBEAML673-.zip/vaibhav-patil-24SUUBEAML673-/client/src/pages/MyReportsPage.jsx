import React, { useState } from 'react';
import { useReports } from '../context/ReportsContext';
import {
  FileText,
  Clock,
  CheckCircle2,
  AlertTriangle,
  MapPin,
  Search,
  Filter,
  ChevronRight,
  Eye,
  PlusCircle,
  Building,
  Radio,
  ArrowRight
} from 'lucide-react';
import DisasterIndicatorBanner from '../components/DisasterIndicatorBanner';

export default function MyReportsPage() {
  const { reports, setActiveTab, currentUser, openAuthModal } = useReports();

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [selectedReport, setSelectedReport] = useState(null);

  if (!currentUser) {
    return (
      <div className="max-w-md mx-auto py-16 px-4 text-center space-y-4">
        <div className="w-14 h-14 rounded-2xl bg-blue-500/10 text-blue-400 flex items-center justify-center mx-auto">
          <FileText className="w-7 h-7" />
        </div>
        <h2 className="text-xl font-bold text-white">Sign In Required</h2>
        <p className="text-xs text-slate-400">
          Please log in with student credentials to view and track your submitted campus reports.
        </p>
        <button
          onClick={() => openAuthModal('student')}
          className="px-6 py-2.5 rounded-xl font-bold text-xs text-white bg-blue-600 hover:bg-blue-500 shadow-glow-blue"
        >
          Sign In as Student
        </button>
      </div>
    );
  }

  const filteredReports = reports.filter(r => {
    const matchSearch =
      search === '' ||
      r.id.toLowerCase().includes(search.toLowerCase()) ||
      r.location.toLowerCase().includes(search.toLowerCase()) ||
      r.description.toLowerCase().includes(search.toLowerCase());

    const matchStatus = statusFilter === 'All' || r.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const getPriorityBadge = (priority) => {
    switch (priority) {
      case 'Critical':
        return 'bg-rose-500/15 text-rose-400 border-rose-500/30';
      case 'High':
        return 'bg-amber-500/15 text-amber-400 border-amber-500/30';
      case 'Medium':
        return 'bg-blue-500/15 text-blue-400 border-blue-500/30';
      default:
        return 'bg-slate-500/15 text-slate-300 border-slate-500/30';
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Resolved':
      case 'Closed':
        return 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30';
      case 'In Progress':
        return 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30';
      case 'Assigned':
        return 'bg-indigo-500/15 text-indigo-400 border-indigo-500/30';
      case 'Under Review':
        return 'bg-amber-500/15 text-amber-400 border-amber-500/30';
      default:
        return 'bg-slate-500/15 text-slate-300 border-slate-500/30';
    }
  };

  // Pipeline Steps
  const pipelineSteps = ['Submitted', 'Under Review', 'Assigned', 'In Progress', 'Resolved'];

  const getStepIndex = (status) => {
    if (status === 'Closed') return 4;
    const idx = pipelineSteps.indexOf(status);
    return idx === -1 ? 0 : idx;
  };

  return (
    <div className="space-y-8 pb-16">
      <DisasterIndicatorBanner />

      {/* Header */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-navy-900 via-slate-900 to-indigo-950/50 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            My Campus Reports
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time tracking of work orders, administrator notes, and resolution statuses.
          </p>
        </div>

        <button
          onClick={() => setActiveTab('report')}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-glow-blue transition active:scale-95 flex-shrink-0"
        >
          <PlusCircle className="w-4 h-4" />
          <span>New Report</span>
        </button>
      </div>

      {/* Search & Filter */}
      <div className="flex flex-col sm:flex-row gap-3 p-4 rounded-2xl glass-panel">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5 pointer-events-none" />
          <input
            type="text"
            placeholder="Search report ID, location, description..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl glass-input text-xs"
          />
        </div>

        <div className="sm:w-48">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3 py-2 rounded-xl glass-input text-xs"
          >
            <option value="All">All Statuses</option>
            <option value="Submitted">Submitted</option>
            <option value="Under Review">Under Review</option>
            <option value="Assigned">Assigned</option>
            <option value="In Progress">In Progress</option>
            <option value="Resolved">Resolved</option>
          </select>
        </div>
      </div>

      {/* Reports List */}
      <div className="space-y-4">
        {filteredReports.map((report) => {
          const stepIdx = getStepIndex(report.status);

          return (
            <div
              key={report.id}
              className="p-5 sm:p-6 rounded-2xl glass-panel border border-slate-800 space-y-4 hover:border-blue-500/40 transition"
            >
              {/* Top Row: Meta badges */}
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-blue-300">
                    {report.id}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${getPriorityBadge(report.priority)}`}>
                    {report.priority}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${getStatusBadge(report.status)}`}>
                    {report.status}
                  </span>
                  <span className="text-xs text-slate-400">
                    {report.category}
                  </span>
                </div>

                <span className="text-xs text-slate-400 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Submitted: {new Date(report.created_at).toLocaleDateString()}</span>
                </span>
              </div>

              {/* Title & Description */}
              <div>
                <h3 className="text-base font-bold text-white mb-1">
                  {report.summary || report.title}
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {report.description}
                </p>
                <div className="flex items-center gap-2 text-xs text-slate-400 mt-2">
                  <MapPin className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />
                  <span>{report.location}</span>
                  <span>•</span>
                  <span>Department: {report.department}</span>
                </div>
              </div>

              {/* Visual Pipeline Progress */}
              <div className="pt-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2 block">
                  Repair Workflow Progress:
                </span>
                <div className="grid grid-cols-5 gap-1 text-center text-[10px]">
                  {pipelineSteps.map((step, idx) => {
                    const isDone = idx <= stepIdx;
                    const isCurrent = idx === stepIdx;

                    return (
                      <div key={step} className="space-y-1">
                        <div className={`h-1.5 rounded-full transition-all ${
                          isDone
                            ? stepIdx === 4 ? 'bg-emerald-500' : 'bg-blue-500'
                            : 'bg-slate-800'
                        }`} />
                        <span className={`truncate block ${
                          isCurrent
                            ? 'font-bold text-white'
                            : isDone
                            ? 'text-slate-300'
                            : 'text-slate-400'
                        }`}>
                          {step}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Administrator Notes / Resolution */}
              {(report.admin_notes || report.resolution_details) && (
                <div className="pt-2 border-t border-slate-800/80 space-y-2 text-xs">
                  {report.admin_notes && (
                    <div className="p-3 rounded-xl bg-blue-950/40 border border-blue-800/40 text-blue-200">
                      <strong>Administrator Note:</strong> {report.admin_notes}
                    </div>
                  )}
                  {report.resolution_details && (
                    <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/40 text-emerald-200">
                      <strong>Resolution Summary:</strong> {report.resolution_details}
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}

        {filteredReports.length === 0 && (
          <div className="p-12 text-center rounded-2xl glass-panel space-y-3">
            <p className="text-slate-400 text-xs">No reports match the current filter.</p>
            <button
              onClick={() => setActiveTab('report')}
              className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-blue-600"
            >
              Report an Issue
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
