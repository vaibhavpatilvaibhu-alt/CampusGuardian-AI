import React from 'react';
import { useReports } from '../context/ReportsContext';
import {
  Shield,
  AlertTriangle,
  GraduationCap,
  KeyRound,
  Radio,
  PhoneCall,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  Lock,
  Building,
  Activity,
  Bot,
  Zap,
  Clock,
  MapPin,
  ExternalLink,
  ShieldAlert
} from 'lucide-react';
import ThemeSelector from '../components/ThemeSelector';
import DisasterIndicatorBanner from '../components/DisasterIndicatorBanner';

export default function WelcomePage() {
  const {
    currentUser,
    openAuthModal,
    setActiveTab,
    activeAlerts,
    publicStats,
    logout
  } = useReports();

  const handleStudentAction = () => {
    if (currentUser?.role === 'student') {
      setActiveTab('dashboard');
    } else if (currentUser?.role === 'admin') {
      // Prompt switch or go to admin
      setActiveTab('dashboard');
    } else {
      openAuthModal('student');
    }
  };

  const handleAdminAction = () => {
    if (currentUser?.role === 'admin') {
      setActiveTab('admin');
    } else {
      openAuthModal('admin');
    }
  };

  return (
    <div className="space-y-12 pb-16">
      {/* Top Welcome Announcement / Active Session Banner */}
      {currentUser ? (
        <div className="p-5 rounded-2xl bg-gradient-to-r from-blue-900/40 via-indigo-900/40 to-slate-900/60 border border-blue-500/40 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400 flex-shrink-0">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                  Active Session Verified
                </span>
                <span className="px-1.5 py-0.2 rounded text-[10px] font-extrabold uppercase bg-blue-500/20 text-blue-300">
                  {currentUser.role}
                </span>
              </div>
              <h2 className="text-base sm:text-lg font-bold text-white">
                Welcome back, {currentUser.name}
              </h2>
              <p className="text-xs text-slate-300">
                You are securely logged in as <code className="text-blue-300">{currentUser.email}</code>. No need to re-enter credentials.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 flex-shrink-0">
            <button
              onClick={() => setActiveTab(currentUser.role === 'admin' ? 'admin' : 'dashboard')}
              className="px-5 py-2.5 rounded-xl font-bold text-xs text-white bg-blue-600 hover:bg-blue-500 shadow-glow-blue transition active:scale-95 flex items-center gap-2"
            >
              <span>Go to {currentUser.role === 'admin' ? 'Administration Hub' : 'Student Dashboard'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={logout}
              className="px-3.5 py-2.5 rounded-xl text-xs font-medium text-slate-300 hover:text-rose-300 hover:bg-slate-800/80 border border-slate-700/60 transition"
            >
              Switch Account
            </button>
          </div>
        </div>
      ) : null}

      {/* Prominent Active Disaster Indicator Banner (if any active alerts) */}
      <DisasterIndicatorBanner />

      {/* Hero Welcome Section */}
      <section className="relative pt-6 sm:pt-10 overflow-hidden text-center">
        {/* Ambient Gradient Glows */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-gradient-to-tr from-blue-600/15 via-indigo-600/20 to-purple-600/15 rounded-full blur-3xl -z-10 pointer-events-none" />

        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900/90 border border-blue-500/30 text-blue-300 text-xs font-semibold mb-6 shadow-sm">
            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
            <span>ENGINEERING HACKATHON: SMART CAMPUS SAFETY PLATFORM</span>
          </div>

          {/* Logo & Project Title */}
          <div className="flex items-center justify-center gap-3.5 mb-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600 flex items-center justify-center shadow-glow-blue">
              <Shield className="w-7 h-7 text-white" />
            </div>
            <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white">
              CampusGuardian{' '}
              <span className="bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-400 bg-clip-text text-transparent">
                AI
              </span>
            </h1>
          </div>

          {/* Tagline */}
          <p className="text-xl sm:text-2xl font-bold text-blue-200 tracking-wide mb-6">
            "A Safer Campus. A Smarter Response."
          </p>

          {/* Short Description */}
          <p className="max-w-2xl mx-auto text-sm sm:text-base text-slate-300 dark:text-slate-300 leading-relaxed mb-10">
            A centralized intelligent campus platform helping students report physical hazards, building repairs, accessibility barriers, and security concerns with AI triage — while empowering administrators with incident tracking, role-based workflows, and campus-wide Disaster Indicator alerts.
          </p>

          {/* Dual Portal Gateways (Student & Admin) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto text-left mb-12">
            {/* Student Gateway Card */}
            <div className="p-6 rounded-2xl glass-panel-interactive border border-blue-500/20 flex flex-col justify-between group">
              <div>
                <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center mb-4 group-hover:scale-105 transition">
                  <GraduationCap className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                  <span>Student Safety Portal</span>
                  {currentUser?.role === 'student' && (
                    <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Active
                    </span>
                  )}
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed mb-4">
                  Report infrastructure issues, broken lights, and accessibility barriers in plain English. Track live repair status, view safety advisories, and get real-time assistance.
                </p>
                <ul className="space-y-1.5 text-xs text-slate-400 mb-6">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />
                    <span>AI-assisted incident triage & category detection</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />
                    <span>Track personal reports & administrative notes</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />
                    <span>View campus-wide disaster alerts & safety guides</span>
                  </li>
                </ul>
              </div>

              <button
                onClick={handleStudentAction}
                className="w-full py-3 px-4 rounded-xl font-bold text-xs text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 shadow-glow-blue transition active:scale-95 flex items-center justify-center gap-2"
              >
                <span>{currentUser?.role === 'student' ? 'Open Student Dashboard' : 'Student Login / Access'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Administration Gateway Card */}
            <div className="p-6 rounded-2xl glass-panel-interactive border border-purple-500/20 flex flex-col justify-between group">
              <div>
                <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center mb-4 group-hover:scale-105 transition">
                  <KeyRound className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                  <span>Administration Hub</span>
                  {currentUser?.role === 'admin' && (
                    <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Active
                    </span>
                  )}
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed mb-4">
                  Centralized command console for campus facilities, dispatch officers, and safety coordinators to manage incident lifecycles, assign work orders, and broadcast emergency alerts.
                </p>
                <ul className="space-y-1.5 text-xs text-slate-400 mb-6">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-purple-400 flex-shrink-0" />
                    <span>Review all campus reports stored in SQLite</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-purple-400 flex-shrink-0" />
                    <span>Assign priority, department & resolution notes</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-purple-400 flex-shrink-0" />
                    <span>Broadcast Disaster Indicator emergency alerts</span>
                  </li>
                </ul>
              </div>

              <button
                onClick={handleAdminAction}
                className="w-full py-3 px-4 rounded-xl font-bold text-xs text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-md transition active:scale-95 flex items-center justify-center gap-2"
              >
                <span>{currentUser?.role === 'admin' ? 'Open Administration Hub' : 'Administration Login / Access'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Hackathon Demo Account Quick Guide */}
          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-300 max-w-xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-blue-400 flex-shrink-0" />
              <span><strong>Demo Accounts:</strong> Pre-configured for evaluation</span>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => openAuthModal('student')}
                className="px-2.5 py-1 rounded-lg text-[11px] bg-blue-500/10 text-blue-300 border border-blue-500/30 hover:bg-blue-500/20 transition"
              >
                student@campusguardian.demo
              </button>
              <button
                onClick={() => openAuthModal('admin')}
                className="px-2.5 py-1 rounded-lg text-[11px] bg-purple-500/10 text-purple-300 border border-purple-500/30 hover:bg-purple-500/20 transition"
              >
                admin@campusguardian.demo
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Emergency and Disaster Alerts Preview Section */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Radio className="w-5 h-5 text-rose-400" />
              <span>Campus Disaster & Emergency Alerts Preview</span>
            </h2>
            <p className="text-xs text-slate-400">
              Live broadcast feed of verified weather watches, infrastructure hazards, and safety bulletins.
            </p>
          </div>

          <button
            onClick={() => setActiveTab('disaster-indicator')}
            className="text-xs font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1"
          >
            <span>Open Disaster Indicator Hub</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>

        {activeAlerts && activeAlerts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {activeAlerts.map((alert) => (
              <div
                key={alert.id}
                className="p-5 rounded-2xl glass-panel border border-slate-700/80 hover:border-blue-500/40 transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-extrabold uppercase ${
                      alert.severity === 'Critical'
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    }`}>
                      {alert.severity} • {alert.category}
                    </span>
                    <span className="text-[10px] text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {new Date(alert.issued_at).toLocaleDateString()}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-white mb-1.5">
                    {alert.title}
                  </h3>

                  <p className="text-xs text-slate-300 line-clamp-2 mb-3">
                    {alert.message}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-800 text-xs flex items-center justify-between text-slate-400">
                  <span className="flex items-center gap-1 text-slate-300">
                    <MapPin className="w-3.5 h-3.5 text-blue-400" />
                    <span>{alert.affected_area}</span>
                  </span>
                  <span className="text-[11px] text-slate-400">
                    {alert.issuing_admin}
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-8 rounded-2xl glass-panel text-center">
            <div className="w-12 h-12 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center mx-auto mb-3">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">All Campus Zones Normal</h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto mt-1">
              There are currently no active critical alerts or severe weather advisories on campus.
            </p>
          </div>
        )}
      </section>

      {/* Safety Notice & Official Disclaimer (Requirement #2 & #6) */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6">
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 text-slate-300 text-xs space-y-3">
          <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
            <ShieldAlert className="w-4 h-4 flex-shrink-0" />
            <span>CAMPUS SAFETY NOTICE & EMERGENCY COMPLIANCE NOTICE</span>
          </div>
          <p className="leading-relaxed">
            CampusGuardian AI is a university incident tracking, facilities dispatch, and internal alert management platform. It is <strong>NOT a replacement for municipal emergency services (911 / 112)</strong> or official campus physical sirens and evacuation protocols.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-[11px] text-slate-400">
            <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
              <strong className="text-slate-200">Demonstration Alerts:</strong> All emergency alerts published within this hackathon instance are marked as <code>[DEMO / SIMULATED]</code> and represent in-app test simulations.
            </div>
            <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
              <strong className="text-slate-200">AI Triage Boundary:</strong> AI classifications are preliminary decision-support recommendations. Official critical alerts require manual authorization by authorized staff.
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
