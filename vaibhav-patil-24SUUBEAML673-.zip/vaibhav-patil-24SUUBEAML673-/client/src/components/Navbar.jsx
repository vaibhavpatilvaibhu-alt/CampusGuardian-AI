import React, { useState } from 'react';
import { useReports } from '../context/ReportsContext';
import {
  Shield,
  LayoutDashboard,
  AlertTriangle,
  FileText,
  Bot,
  SlidersHorizontal,
  Accessibility,
  PhoneCall,
  Radio,
  LogOut,
  User,
  Sparkles,
  Menu,
  X,
  KeyRound,
  GraduationCap
} from 'lucide-react';
import ThemeSelector from './ThemeSelector';
import EmergencyModal from './EmergencyModal';

export default function Navbar() {
  const {
    activeTab,
    setActiveTab,
    currentUser,
    logout,
    openAuthModal,
    systemHealth,
    reports,
    activeAlerts
  } = useReports();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [emergencyModalOpen, setEmergencyModalOpen] = useState(false);

  const pendingCount = reports.filter(r => r.status !== 'Resolved' && r.status !== 'Closed').length;
  const isGemini = systemHealth?.aiEngine?.geminiConfigured;

  const handleNavClick = (id) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
  };

  // Nav Items tailored by role
  const navItems = [
    { id: 'welcome', label: 'Welcome', icon: Shield },
    ...(currentUser ? [
      currentUser.role === 'admin'
        ? { id: 'admin', label: 'Admin Hub', icon: SlidersHorizontal, highlight: true }
        : { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { id: 'report', label: 'Report Issue', icon: AlertTriangle },
      { id: 'my-reports', label: 'My Reports', icon: FileText, badge: pendingCount > 0 ? pendingCount : null },
    ] : []),
    {
      id: 'disaster-indicator',
      label: 'Disaster Indicator',
      icon: Radio,
      alertCount: activeAlerts.length > 0 ? activeAlerts.length : null
    },
    { id: 'assistant', label: 'AI Assistant', icon: Bot },
    { id: 'emergency', label: 'Emergency SOS', icon: PhoneCall, urgent: true },
    { id: 'accessibility', label: 'Accessibility', icon: Accessibility }
  ];

  return (
    <>
      <header className="sticky top-0 z-40 w-full bg-slate-950/90 dark:bg-navy-950/90 backdrop-blur-xl border-b border-slate-800/80 transition-all text-slate-100">
        {/* Top Mini Telemetry Banner */}
        <div className="bg-gradient-to-r from-blue-950/80 via-indigo-950/80 to-purple-950/80 border-b border-slate-800/60 px-4 py-1 text-xs flex items-center justify-between text-slate-300">
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="font-semibold text-slate-200">CampusGuardian AI</span>
            <span className="hidden sm:inline text-slate-400">— "A Safer Campus. A Smarter Response."</span>
          </div>

          <div className="flex items-center gap-3">
            {/* AI Status Badge */}
            <div className={`hidden md:flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-medium border ${
              isGemini
                ? 'bg-blue-500/10 border-blue-500/30 text-blue-300'
                : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
            }`}>
              <Sparkles className="w-3 h-3" />
              <span>{isGemini ? 'Gemini 2.0 AI Online' : 'Local AI Engine Active'}</span>
            </div>

            {/* Compact Theme Selector */}
            <ThemeSelector compact={true} />

            {/* User Session Status */}
            {currentUser ? (
              <div className="flex items-center gap-2 bg-slate-900/90 px-2 py-0.5 rounded-lg border border-slate-800 text-[11px]">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="text-slate-300 font-medium truncate max-w-[120px]">
                  {currentUser.name.split(' ')[0]}
                </span>
                <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold uppercase ${
                  currentUser.role === 'admin'
                    ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                    : 'bg-blue-500/20 text-blue-300 border border-blue-500/40'
                }`}>
                  {currentUser.role}
                </span>
                <button
                  onClick={logout}
                  title="Sign out of your session"
                  className="text-slate-400 hover:text-rose-400 ml-1 p-0.5 transition"
                  aria-label="Logout"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => openAuthModal('student')}
                  className="px-2 py-0.5 rounded text-[11px] bg-blue-600/30 hover:bg-blue-600/50 text-blue-200 border border-blue-500/40 transition"
                >
                  Student Login
                </button>
                <button
                  onClick={() => openAuthModal('admin')}
                  className="px-2 py-0.5 rounded text-[11px] bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 border border-purple-500/40 transition"
                >
                  Admin Login
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Main Navbar */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          {/* Logo & Brand */}
          <div
            onClick={() => handleNavClick('welcome')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="relative">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600 flex items-center justify-center shadow-glow-blue group-hover:scale-105 transition-transform">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full border-2 border-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-lg font-extrabold tracking-tight text-white group-hover:text-blue-300 transition-colors">
                  CampusGuardian
                </span>
                <span className="px-1.5 py-0.5 text-[10px] font-extrabold uppercase rounded bg-gradient-to-r from-blue-500 to-indigo-500 text-white shadow-sm">
                  AI
                </span>
              </div>
              <p className="text-[10px] text-slate-400 -mt-0.5 font-medium tracking-wide">
                Smart Campus Safety & Operations
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`relative flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-blue-600/25 text-blue-300 border border-blue-500/40 shadow-sm'
                      : item.highlight
                      ? 'bg-purple-600 hover:bg-purple-500 text-white shadow-md'
                      : item.urgent
                      ? 'text-rose-300 hover:bg-rose-500/10'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${item.urgent ? 'text-rose-400 animate-pulse' : ''}`} />
                  <span>{item.label}</span>

                  {/* Active Alerts Pill */}
                  {item.alertCount && (
                    <span className="px-1.5 py-0.2 rounded-full text-[10px] font-extrabold bg-rose-500 text-white animate-pulse">
                      {item.alertCount}
                    </span>
                  )}

                  {/* Pending Reports Badge */}
                  {item.badge && (
                    <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Desktop Right Actions */}
          <div className="hidden lg:flex items-center gap-2.5">
            <button
              onClick={() => setEmergencyModalOpen(true)}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold text-rose-200 bg-rose-950/50 hover:bg-rose-900/60 border border-rose-500/40 shadow-glow-rose transition active:scale-95"
            >
              <PhoneCall className="w-3.5 h-3.5 text-rose-400" />
              <span>SOS Dispatch</span>
            </button>

            {currentUser ? (
              <button
                onClick={logout}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium text-slate-300 hover:text-rose-300 hover:bg-slate-800/80 border border-slate-800 transition"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Log Out</span>
              </button>
            ) : (
              <button
                onClick={() => openAuthModal('student')}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 shadow-glow-blue transition active:scale-95"
              >
                <User className="w-3.5 h-3.5" />
                <span>Sign In</span>
              </button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={() => setEmergencyModalOpen(true)}
              className="p-2 rounded-xl text-rose-300 bg-rose-950/60 border border-rose-500/40"
              aria-label="Emergency SOS"
            >
              <PhoneCall className="w-4 h-4" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-slate-800 bg-slate-950/95 backdrop-blur-2xl px-4 pt-3 pb-6 space-y-2 text-slate-100">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition ${
                    isActive
                      ? 'bg-blue-600/20 text-blue-300 border border-blue-500/30'
                      : 'text-slate-300 hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className="w-4 h-4 text-slate-400" />
                    <span>{item.label}</span>
                  </div>
                  {item.alertCount && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500 text-white">
                      {item.alertCount} Alerts
                    </span>
                  )}
                </button>
              );
            })}

            <div className="pt-3 border-t border-slate-800/80 flex flex-col gap-2">
              {currentUser ? (
                <button
                  onClick={() => { logout(); setMobileMenuOpen(false); }}
                  className="w-full py-2.5 rounded-xl text-xs font-semibold text-rose-300 bg-rose-950/40 border border-rose-500/30 flex items-center justify-center gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Log Out ({currentUser.name})</span>
                </button>
              ) : (
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => { openAuthModal('student'); setMobileMenuOpen(false); }}
                    className="py-2.5 rounded-xl text-xs font-semibold text-white bg-blue-600 text-center"
                  >
                    Student Login
                  </button>
                  <button
                    onClick={() => { openAuthModal('admin'); setMobileMenuOpen(false); }}
                    className="py-2.5 rounded-xl text-xs font-semibold text-white bg-purple-600 text-center"
                  >
                    Admin Login
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Emergency Modal */}
      {emergencyModalOpen && (
        <EmergencyModal onClose={() => setEmergencyModalOpen(false)} />
      )}
    </>
  );
}
