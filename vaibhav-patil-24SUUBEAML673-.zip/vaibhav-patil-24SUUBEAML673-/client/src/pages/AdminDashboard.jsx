import React, { useState, useEffect } from 'react';
import { useReports } from '../context/ReportsContext';
import {
  fetchServerAuditLogs,
  exportReportsFile,
  fetchAdminStats
} from '../services/api';
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend
} from 'recharts';
import {
  ShieldAlert,
  Sliders,
  CheckCircle,
  Clock,
  AlertTriangle,
  Search,
  Filter,
  Check,
  Building,
  RefreshCw,
  Eye,
  X,
  FileSpreadsheet,
  Download,
  Radio,
  FileText,
  Activity,
  History,
  UserCheck,
  Send,
  Layers,
  ChevronDown
} from 'lucide-react';
import DisasterIndicatorBanner from '../components/DisasterIndicatorBanner';
import ThemeSelector from '../components/ThemeSelector';

export default function AdminDashboard() {
  const {
    reports,
    updateReport,
    addToast,
    refreshReports,
    authToken,
    activeAlerts,
    setActiveTab,
    currentUser
  } = useReports();

  // Active Tab View in Admin Hub
  const [adminView, setAdminView] = useState('reports'); // 'reports' | 'alerts' | 'audit'

  // Filters
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [priorityFilter, setPriorityFilter] = useState('All');
  const [categoryFilter, setCategoryFilter] = useState('All');

  // Selected Report Modal
  const [selectedReport, setSelectedReport] = useState(null);
  const [editStatus, setEditStatus] = useState('');
  const [editPriority, setEditPriority] = useState('');
  const [editDepartment, setEditDepartment] = useState('');
  const [editStaff, setEditStaff] = useState('');
  const [adminNotes, setAdminNotes] = useState('');
  const [resolutionDetails, setResolutionDetails] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);

  // Audit Logs State
  const [auditLogs, setAuditLogs] = useState([]);
  const [isAuditLoading, setIsAuditLoading] = useState(false);

  // Export State
  const [isExporting, setIsExporting] = useState(false);

  // Load audit logs when switching to 'audit' tab
  useEffect(() => {
    if (adminView === 'audit' && authToken) {
      loadAuditLogs();
    }
  }, [adminView, authToken]);

  const loadAuditLogs = async () => {
    setIsAuditLoading(true);
    const logs = await fetchServerAuditLogs(authToken);
    setAuditLogs(logs || []);
    setIsAuditLoading(false);
  };

  // Open Edit Modal
  const handleOpenEdit = (report) => {
    setSelectedReport(report);
    setEditStatus(report.status);
    setEditPriority(report.priority);
    setEditDepartment(report.department);
    setEditStaff(report.assigned_staff || report.assignedStaff || '');
    setAdminNotes(report.admin_notes || '');
    setResolutionDetails(report.resolution_details || '');
  };

  // Save Report Edits
  const handleSaveReport = async () => {
    if (!selectedReport) return;
    setIsUpdating(true);
    try {
      await updateReport(selectedReport.id, {
        status: editStatus,
        priority: editPriority,
        department: editDepartment,
        assignedStaff: editStaff,
        adminNotes: adminNotes,
        resolutionDetails: resolutionDetails,
        note: `Report updated by Admin (${currentUser?.name || 'Administrator'})`
      });
      setSelectedReport(null);
    } catch (err) {
      // Toast already shown in context
    } finally {
      setIsUpdating(false);
    }
  };

  // Handle Export
  const handleExport = async (format) => {
    setIsExporting(true);
    try {
      await exportReportsFile(format, authToken);
      addToast('Data Export Complete', `Downloaded campus reports in ${format.toUpperCase()} format.`, 'success');
    } catch (err) {
      addToast('Export Failed', err.message, 'error');
    } finally {
      setIsExporting(false);
    }
  };

  // Computed metrics from real SQLite reports
  const totalReports = reports.length;
  const newReports = reports.filter(r => r.status === 'Submitted').length;
  const inProgressReports = reports.filter(r => ['Under Review', 'Assigned', 'In Progress'].includes(r.status)).length;
  const resolvedReports = reports.filter(r => ['Resolved', 'Closed'].includes(r.status)).length;
  const criticalReports = reports.filter(r => r.priority === 'Critical').length;
  const activeAlertsCount = activeAlerts.length;

  // Chart 1: Category Distribution
  const categoryCounts = reports.reduce((acc, r) => {
    acc[r.category] = (acc[r.category] || 0) + 1;
    return acc;
  }, {});

  const categoryChartData = Object.entries(categoryCounts).map(([name, count]) => ({
    name,
    count
  }));

  // Chart 2: Priority Distribution
  const priorityOrder = ['Critical', 'High', 'Medium', 'Low'];
  const priorityColors = {
    Critical: '#EF4444',
    High: '#F59E0B',
    Medium: '#3B82F6',
    Low: '#64748B'
  };

  const priorityChartData = priorityOrder.map(p => ({
    name: p,
    value: reports.filter(r => r.priority === p).length
  })).filter(item => item.value > 0);

  // Filtered reports for table
  const filteredReports = reports.filter(r => {
    const matchSearch =
      search === '' ||
      r.id.toLowerCase().includes(search.toLowerCase()) ||
      r.location.toLowerCase().includes(search.toLowerCase()) ||
      r.description.toLowerCase().includes(search.toLowerCase()) ||
      (r.department && r.department.toLowerCase().includes(search.toLowerCase()));

    const matchStatus = statusFilter === 'All' || r.status === statusFilter;
    const matchPriority = priorityFilter === 'All' || r.priority === priorityFilter;
    const matchCategory = categoryFilter === 'All' || r.category === categoryFilter;

    return matchSearch && matchStatus && matchPriority && matchCategory;
  });

  const departmentOptions = [
    'Campus Fire & Life Safety Operations',
    'Campus Electrical & Utility Services',
    'Facilities Management & Maintenance',
    'Campus Security & Safety Operations',
    'Disability & Accessibility Infrastructure',
    'Campus Health & Emergency Medical Services',
    'Campus Environmental & Custodial Services',
    'Campus IT & Audiovisual Infrastructure',
    'General Campus Operations'
  ];

  const statusOptions = [
    'Submitted',
    'Under Review',
    'Assigned',
    'In Progress',
    'Resolved',
    'Closed'
  ];

  const categoryOptions = [
    'Fire Safety',
    'Electrical Issue',
    'Building Maintenance',
    'Security',
    'Medical Assistance',
    'Accessibility',
    'Sanitation',
    'Other'
  ];

  return (
    <div className="space-y-8 pb-16">
      {/* Active Disaster Indicator Banner */}
      <DisasterIndicatorBanner />

      {/* Admin Command Header */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-navy-900 via-slate-900 to-purple-950/60 border border-slate-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="p-1.5 rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20">
              <Sliders className="w-4 h-4" />
            </span>
            <span className="text-xs font-bold text-purple-400 uppercase tracking-wider">
              Administration Operations Command • SQLite Persistent DB
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            Campus Operations & Safety Console
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl">
            Triage submitted student incident reports, assign maintenance work orders, broadcast campus emergency alerts, and inspect audit logs.
          </p>
        </div>

        {/* Header Action Tools */}
        <div className="flex flex-wrap items-center gap-3">
          <ThemeSelector />

          <button
            onClick={() => refreshReports()}
            className="p-2.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-300 transition"
            title="Refresh database records"
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          {/* Export Dropdown */}
          <div className="flex items-center gap-1 bg-slate-900/80 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => handleExport('csv')}
              disabled={isExporting}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5 transition"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
            <button
              onClick={() => handleExport('json')}
              disabled={isExporting}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 flex items-center gap-1.5 transition"
            >
              <Download className="w-3.5 h-3.5" />
              <span>JSON</span>
            </button>
          </div>

          <button
            onClick={() => setActiveTab('disaster-indicator')}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-bold text-xs shadow-glow-rose transition active:scale-95"
          >
            <Radio className="w-4 h-4" />
            <span>Disaster Hub</span>
          </button>
        </div>
      </div>

      {/* 6 Core Calculated Telemetry Cards (From SQLite) */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Total */}
        <div className="p-4 rounded-xl glass-panel">
          <p className="text-[11px] text-slate-400 font-medium flex items-center gap-1">
            <FileText className="w-3.5 h-3.5 text-blue-400" />
            <span>Total Reports</span>
          </p>
          <p className="text-2xl font-extrabold text-white mt-1">{totalReports}</p>
          <p className="text-[10px] text-slate-400">Stored in SQLite</p>
        </div>

        {/* New / Submitted */}
        <div className="p-4 rounded-xl glass-panel">
          <p className="text-[11px] text-slate-400 font-medium flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>New Triage</span>
          </p>
          <p className="text-2xl font-extrabold text-amber-400 mt-1">{newReports}</p>
          <p className="text-[10px] text-amber-400/80">Pending review</p>
        </div>

        {/* In Progress */}
        <div className="p-4 rounded-xl glass-panel">
          <p className="text-[11px] text-slate-400 font-medium flex items-center gap-1">
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
            <span>In Progress</span>
          </p>
          <p className="text-2xl font-extrabold text-cyan-400 mt-1">{inProgressReports}</p>
          <p className="text-[10px] text-cyan-400/80">Active work orders</p>
        </div>

        {/* Resolved */}
        <div className="p-4 rounded-xl glass-panel">
          <p className="text-[11px] text-slate-400 font-medium flex items-center gap-1">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span>Resolved</span>
          </p>
          <p className="text-2xl font-extrabold text-emerald-400 mt-1">{resolvedReports}</p>
          <p className="text-[10px] text-emerald-400/80">Completed repairs</p>
        </div>

        {/* Critical */}
        <div className="p-4 rounded-xl glass-panel">
          <p className="text-[11px] text-slate-400 font-medium flex items-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
            <span>Critical Incidents</span>
          </p>
          <p className="text-2xl font-extrabold text-rose-400 mt-1">{criticalReports}</p>
          <p className="text-[10px] text-rose-400/80">Immediate priority</p>
        </div>

        {/* Active Alerts */}
        <div className="p-4 rounded-xl glass-panel cursor-pointer" onClick={() => setActiveTab('disaster-indicator')}>
          <p className="text-[11px] text-slate-400 font-medium flex items-center gap-1">
            <Radio className="w-3.5 h-3.5 text-rose-400" />
            <span>Active Alerts</span>
          </p>
          <p className="text-2xl font-extrabold text-rose-400 mt-1">{activeAlertsCount}</p>
          <p className="text-[10px] text-rose-400/80">Campus broadcasts</p>
        </div>
      </div>

      {/* Visual Analytics Charts (Recharts) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Category Breakdown Bar Chart */}
        <div className="p-6 rounded-2xl glass-panel space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-blue-400" />
              <span>Incident Category Distribution</span>
            </h3>
            <span className="text-[11px] text-slate-400">Calculated from SQLite database</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categoryChartData} margin={{ top: 10, right: 10, left: -20, bottom: 25 }}>
                <XAxis dataKey="name" stroke="#94A3B8" fontSize={10} angle={-25} textAnchor="end" interval={0} />
                <YAxis stroke="#94A3B8" fontSize={11} allowDecimals={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0B1120', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                  itemStyle={{ color: '#F8FAFC' }}
                />
                <Bar dataKey="count" fill="#3B82F6" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Priority Breakdown Pie Chart */}
        <div className="p-6 rounded-2xl glass-panel space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-purple-400" />
              <span>Incident Priority Levels</span>
            </h3>
            <span className="text-[11px] text-slate-400">Real-time breakdown</span>
          </div>

          <div className="h-64 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={priorityChartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}`}
                  labelLine={false}
                >
                  {priorityChartData.map((entry) => (
                    <Cell key={entry.name} fill={priorityColors[entry.name] || '#64748B'} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#0B1120', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                />
                <Legend verticalAlign="bottom" height={36} iconSize={10} wrapperStyle={{ fontSize: '11px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Sub-Tabs: Reports Table vs. System Audit Trail */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setAdminView('reports')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
            adminView === 'reports'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Campus Reports Registry ({filteredReports.length})</span>
        </button>

        <button
          onClick={() => setAdminView('audit')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
            adminView === 'audit'
              ? 'bg-purple-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <History className="w-4 h-4" />
          <span>System Audit Trail Log</span>
        </button>
      </div>

      {/* VIEW 1: Reports Management Table */}
      {adminView === 'reports' && (
        <div className="space-y-4">
          {/* Search & Filter Toolbar */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 p-4 rounded-2xl glass-panel">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
              <input
                type="text"
                placeholder="Search ID, location, summary..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl glass-input text-xs"
              />
            </div>

            {/* Status Filter */}
            <div>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full px-3 py-2 rounded-xl glass-input text-xs"
              >
                <option value="All">All Statuses</option>
                {statusOptions.map(st => (
                  <option key={st} value={st}>{st}</option>
                ))}
              </select>
            </div>

            {/* Priority Filter */}
            <div>
              <select
                value={priorityFilter}
                onChange={(e) => setPriorityFilter(e.target.value)}
                className="w-full px-3 py-2 rounded-xl glass-input text-xs"
              >
                <option value="All">All Priorities</option>
                <option value="Critical">Critical</option>
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>

            {/* Category Filter */}
            <div>
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="w-full px-3 py-2 rounded-xl glass-input text-xs"
              >
                <option value="All">All Categories</option>
                {categoryOptions.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Table Container */}
          <div className="rounded-2xl glass-panel overflow-hidden border border-slate-800">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-900/60 text-slate-400">
                    <th className="p-3.5 font-bold">Report ID</th>
                    <th className="p-3.5 font-bold">Category</th>
                    <th className="p-3.5 font-bold">Priority</th>
                    <th className="p-3.5 font-bold">Status</th>
                    <th className="p-3.5 font-bold">Location & Issue</th>
                    <th className="p-3.5 font-bold">Department</th>
                    <th className="p-3.5 font-bold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-200">
                  {filteredReports.map((r) => (
                    <tr key={r.id} className="hover:bg-slate-800/40 transition">
                      <td className="p-3.5 font-bold text-white whitespace-nowrap">
                        {r.id}
                      </td>
                      <td className="p-3.5 whitespace-nowrap">
                        <span className="px-2 py-0.5 rounded text-[11px] bg-slate-800 text-slate-300 border border-slate-700">
                          {r.category}
                        </span>
                      </td>
                      <td className="p-3.5 whitespace-nowrap">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${
                          r.priority === 'Critical' ? 'bg-rose-500/15 text-rose-400 border-rose-500/30' :
                          r.priority === 'High' ? 'bg-amber-500/15 text-amber-400 border-amber-500/30' :
                          r.priority === 'Medium' ? 'bg-blue-500/15 text-blue-400 border-blue-500/30' :
                          'bg-slate-500/15 text-slate-400 border-slate-500/30'
                        }`}>
                          {r.priority}
                        </span>
                      </td>
                      <td className="p-3.5 whitespace-nowrap">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                          r.status === 'Resolved' || r.status === 'Closed' ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30' :
                          r.status === 'In Progress' ? 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30' :
                          r.status === 'Assigned' ? 'bg-indigo-500/15 text-indigo-400 border-indigo-500/30' :
                          r.status === 'Under Review' ? 'bg-amber-500/15 text-amber-400 border-amber-500/30' :
                          'bg-slate-500/15 text-slate-300 border-slate-500/30'
                        }`}>
                          {r.status}
                        </span>
                      </td>
                      <td className="p-3.5 max-w-xs truncate">
                        <div className="font-semibold text-white truncate">
                          {r.summary || r.title}
                        </div>
                        <div className="text-[11px] text-slate-400 truncate flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-blue-400 flex-shrink-0" />
                          <span>{r.location}</span>
                        </div>
                      </td>
                      <td className="p-3.5 text-slate-300 text-[11px] max-w-[180px] truncate">
                        {r.department}
                      </td>
                      <td className="p-3.5 text-right whitespace-nowrap">
                        <button
                          onClick={() => handleOpenEdit(r)}
                          className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 transition flex items-center gap-1 ml-auto"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Review & Triage</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                  {filteredReports.length === 0 && (
                    <tr>
                      <td colSpan={7} className="p-8 text-center text-slate-400 text-xs">
                        No reports matching your search and filter criteria.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: System Audit Trail Log */}
      {adminView === 'audit' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <History className="w-4 h-4 text-purple-400" />
                <span>Administrative Action Audit Trail</span>
              </h3>
              <p className="text-xs text-slate-400">
                Immutable chronological log of administrator actions, status transitions, and emergency alert publications.
              </p>
            </div>
            <button
              onClick={loadAuditLogs}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
              title="Refresh audit logs"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>

          <div className="rounded-2xl glass-panel overflow-hidden border border-slate-800">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-900/60 text-slate-400">
                    <th className="p-3 font-bold">Timestamp</th>
                    <th className="p-3 font-bold">Administrator</th>
                    <th className="p-3 font-bold">Action</th>
                    <th className="p-3 font-bold">Details</th>
                    <th className="p-3 font-bold">Target ID</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  {auditLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-800/30 transition">
                      <td className="p-3 whitespace-nowrap text-slate-400 text-[11px]">
                        {new Date(log.timestamp).toLocaleString()}
                      </td>
                      <td className="p-3 whitespace-nowrap font-medium text-white">
                        {log.actor_email} ({log.actor_role})
                      </td>
                      <td className="p-3 whitespace-nowrap">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-purple-500/20 text-purple-300 border border-purple-500/30">
                          {log.action}
                        </span>
                      </td>
                      <td className="p-3 max-w-md text-slate-200">
                        {log.details}
                      </td>
                      <td className="p-3 whitespace-nowrap font-mono text-[11px] text-blue-300">
                        {log.target_id || '—'}
                      </td>
                    </tr>
                  ))}
                  {auditLogs.length === 0 && !isAuditLoading && (
                    <tr>
                      <td colSpan={5} className="p-8 text-center text-slate-400 text-xs">
                        No audit logs found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Review & Triage Modal */}
      {selectedReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-navy-950/85 backdrop-blur-md">
          <div className="relative w-full max-w-2xl rounded-2xl glass-panel bg-slate-900/95 border border-slate-700/80 p-6 sm:p-8 shadow-2xl max-h-[90vh] overflow-y-auto space-y-6">
            <button
              onClick={() => setSelectedReport(null)}
              className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Header */}
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-bold px-2 py-0.5 rounded bg-blue-500/20 text-blue-300">
                  {selectedReport.id}
                </span>
                <span className="text-xs text-slate-400">
                  Reported by: {selectedReport.reporter_name || selectedReport.reporter} ({selectedReport.student_email})
                </span>
              </div>
              <h3 className="text-lg font-bold text-white">
                {selectedReport.summary || selectedReport.title}
              </h3>
            </div>

            {/* Original Student Observation */}
            <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 text-xs space-y-2">
              <span className="text-slate-400 font-bold uppercase tracking-wide">
                Student Submitted Observation:
              </span>
              <p className="text-slate-200 leading-relaxed">
                "{selectedReport.description}"
              </p>
              <div className="flex items-center gap-2 text-slate-400 pt-1">
                <MapPin className="w-3.5 h-3.5 text-blue-400" />
                <span>Location: {selectedReport.location}</span>
                <span>•</span>
                <span>AI Confidence: {selectedReport.confidence}%</span>
              </div>
            </div>

            {/* Admin Work Order Assignment Form */}
            <div className="space-y-4">
              <h4 className="text-xs font-bold text-purple-400 uppercase tracking-wider">
                Administrator Work Order Controls
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Workflow Status
                  </label>
                  <select
                    value={editStatus}
                    onChange={(e) => setEditStatus(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl glass-input text-xs"
                  >
                    {statusOptions.map(st => (
                      <option key={st} value={st} className="bg-slate-900 text-white">
                        {st}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Triage Priority
                  </label>
                  <select
                    value={editPriority}
                    onChange={(e) => setEditPriority(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl glass-input text-xs"
                  >
                    <option value="Critical" className="bg-slate-900 text-white">Critical</option>
                    <option value="High" className="bg-slate-900 text-white">High</option>
                    <option value="Medium" className="bg-slate-900 text-white">Medium</option>
                    <option value="Low" className="bg-slate-900 text-white">Low</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Responsible Department
                  </label>
                  <select
                    value={editDepartment}
                    onChange={(e) => setEditDepartment(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl glass-input text-xs"
                  >
                    {departmentOptions.map(dept => (
                      <option key={dept} value={dept} className="bg-slate-900 text-white">
                        {dept}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Assigned Field Officer / Staff
                  </label>
                  <input
                    type="text"
                    value={editStaff}
                    onChange={(e) => setEditStaff(e.target.value)}
                    placeholder="e.g. Officer M. Davies (Facilities)"
                    className="w-full px-3 py-2.5 rounded-xl glass-input text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Administrative Notes (Visible to Student)
                </label>
                <textarea
                  rows={2}
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  placeholder="e.g. Electrician team dispatched with replacement fixture..."
                  className="w-full px-3 py-2.5 rounded-xl glass-input text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Resolution Details (Required when resolving)
                </label>
                <textarea
                  rows={2}
                  value={resolutionDetails}
                  onChange={(e) => setResolutionDetails(e.target.value)}
                  placeholder="e.g. Ballast replaced, illumination tested, hazard cleared."
                  className="w-full px-3 py-2.5 rounded-xl glass-input text-xs"
                />
              </div>
            </div>

            {/* Modal Actions */}
            <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setSelectedReport(null)}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isUpdating}
                onClick={handleSaveReport}
                className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 shadow-glow-blue transition active:scale-95 flex items-center gap-2"
              >
                <Check className="w-4 h-4" />
                <span>{isUpdating ? 'Saving to SQLite...' : 'Save & Update Work Order'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
