import React, { useState } from 'react';
import { useReports } from '../context/ReportsContext';
import { analyzeIssueWithAI } from '../services/api';
import {
  Sparkles,
  MapPin,
  Camera,
  AlertCircle,
  CheckCircle2,
  Send,
  Loader2,
  RefreshCw,
  Building,
  Sliders,
  ShieldCheck,
  FileCheck,
  ArrowRight,
  Info,
  Radio,
  Clock
} from 'lucide-react';
import DisasterIndicatorBanner from '../components/DisasterIndicatorBanner';

export default function ReportIssuePage() {
  const { addReport, setActiveTab, addToast, currentUser, openAuthModal } = useReports();

  // Form State
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [optionalCategory, setOptionalCategory] = useState('');
  const [imagePreview, setImagePreview] = useState(null);

  // AI State
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiResult, setAiResult] = useState(null);

  // Submission State
  const [submittedReport, setSubmittedReport] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const categories = [
    'Fire Safety',
    'Electrical Issue',
    'Building Maintenance',
    'Security',
    'Medical Assistance',
    'Accessibility',
    'Sanitation',
    'Other'
  ];

  // Quick Preset Prompts
  const quickPresets = [
    {
      title: 'Staircase Lighting',
      text: 'The staircase light near Block C has been broken for three days and it is very dark at night.',
      loc: 'Block C - Staircase 2nd Floor'
    },
    {
      title: 'Blocked Wheelchair Ramp',
      text: 'The wheelchair ramp at the Library north entrance is obstructed by heavy delivery crates and wooden pallets.',
      loc: 'Central Library - North Ramp'
    },
    {
      title: 'Projector HDMI Sparking',
      text: 'The projector in Science Hall 302 sparks when HDMI is plugged in and will not project lecture slides.',
      loc: 'Science Complex - Room 302'
    },
    {
      title: 'Urgent Washroom Leak',
      text: 'A high-pressure pipe under the washroom sink in Engineering Wing B is leaking water across the hallway.',
      loc: 'Engineering Wing B - Ground Floor Restroom'
    }
  ];

  const quickLocations = [
    'Block C - Staircase',
    'Central Library - North Ramp',
    'Science Complex - Hall 302',
    'Engineering Wing B - Restroom',
    'Student Center - Main Plaza',
    'Campus Dining Commons'
  ];

  const handleSelectPreset = (preset) => {
    setDescription(preset.text);
    setLocation(preset.loc);
    setAiResult(null);
  };

  const handleImageUpload = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyzeWithAI = async () => {
    if (!description.trim()) {
      addToast('Input Required', 'Please enter a description of the campus issue.', 'warning');
      return;
    }

    setIsAnalyzing(true);
    setAiResult(null);

    try {
      const result = await analyzeIssueWithAI(description.trim(), location.trim());
      setAiResult(result);
      if (result.category) {
        setOptionalCategory(result.category);
      }
      addToast('AI Triage Complete', `Detected ${result.category} (${result.priority} Priority)`, 'success');
    } catch (err) {
      addToast('Analysis Notice', 'Using local offline rule engine.', 'info');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSubmitReport = async (e) => {
    e.preventDefault();

    if (!currentUser) {
      addToast('Authentication Required', 'Please sign in with student credentials to file a report.', 'warning');
      openAuthModal('student');
      return;
    }

    if (!description.trim() || !location.trim()) {
      addToast('Missing Fields', 'Please provide both an issue description and location.', 'warning');
      return;
    }

    setIsSubmitting(true);
    try {
      let finalCategory = optionalCategory || aiResult?.category || 'Other';
      let finalPriority = aiResult?.priority || 'Medium';
      let finalDept = aiResult?.department || 'General Campus Operations';
      let finalSummary = aiResult?.summary || description.slice(0, 60);
      let finalAction = aiResult?.recommendedAction || 'Inspect and address reported issue.';
      let confidence = aiResult?.confidence || 92;

      const reportData = {
        description: description.trim(),
        location: location.trim(),
        category: finalCategory,
        priority: finalPriority,
        department: finalDept,
        summary: finalSummary,
        recommendedAction: finalAction,
        confidence: confidence,
        imageUrl: imagePreview
      };

      const created = await addReport(reportData);
      setSubmittedReport(created);
    } catch (err) {
      // Toast already shown in context
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetForm = () => {
    setDescription('');
    setLocation('');
    setOptionalCategory('');
    setImagePreview(null);
    setAiResult(null);
    setSubmittedReport(null);
  };

  // SUCCESS VIEW
  if (submittedReport) {
    return (
      <div className="max-w-2xl mx-auto py-12 px-4 text-center space-y-6 animate-fade-in">
        <div className="w-16 h-16 rounded-3xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto shadow-glow-emerald">
          <CheckCircle2 className="w-8 h-8" />
        </div>

        <div className="space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
            Persistent SQLite Record Stored
          </span>
          <h2 className="text-3xl font-extrabold text-white">
            Incident Report Logged
          </h2>
          <p className="text-sm text-slate-400">
            Your observation has been assigned a tracking ID and routed to university operations.
          </p>
        </div>

        <div className="p-6 rounded-2xl glass-panel text-left space-y-4 border border-slate-700">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <span className="text-xs text-slate-400">Unique Tracking ID</span>
              <p className="text-lg font-mono font-bold text-blue-400">{submittedReport.id}</p>
            </div>
            <div className="text-right">
              <span className="text-xs text-slate-400">Status</span>
              <p className="text-sm font-bold text-amber-400">{submittedReport.status}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <span className="text-slate-400">Category:</span>
              <p className="font-semibold text-white">{submittedReport.category}</p>
            </div>
            <div>
              <span className="text-slate-400">Assigned Department:</span>
              <p className="font-semibold text-white">{submittedReport.department}</p>
            </div>
            <div>
              <span className="text-slate-400">Location:</span>
              <p className="font-semibold text-white">{submittedReport.location}</p>
            </div>
            <div>
              <span className="text-slate-400">Priority:</span>
              <p className="font-semibold text-rose-400">{submittedReport.priority}</p>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs">
            <span className="text-slate-400 font-medium">Recommended Action:</span>
            <p className="text-slate-200 mt-0.5">{submittedReport.recommended_action || submittedReport.recommendedAction}</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
          <button
            onClick={() => setActiveTab('my-reports')}
            className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm shadow-glow-blue transition active:scale-95 flex items-center gap-2"
          >
            <span>Track in My Reports</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={handleResetForm}
            className="px-6 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 font-semibold text-xs sm:text-sm border border-slate-700 transition"
          >
            Submit Another Report
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-16 max-w-4xl mx-auto">
      <DisasterIndicatorBanner />

      {/* Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-300 text-xs font-semibold">
          <Sparkles className="w-3.5 h-3.5" />
          <span>AI-POWERED INCIDENT CLASSIFICATION</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white">
          Report a Campus Safety or Facility Issue
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto">
          Describe the situation in plain words. Our AI engine triages urgency, classifies the issue, and alerts the appropriate campus maintenance crew.
        </p>
      </div>

      {/* Quick Preset Prompts */}
      <div className="p-4 sm:p-5 rounded-2xl glass-panel space-y-2.5">
        <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>Quick Hackathon Test Scenarios:</span>
        </span>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {quickPresets.map((preset, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleSelectPreset(preset)}
              className="p-3 rounded-xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-800 text-left transition group text-xs"
            >
              <p className="font-semibold text-white group-hover:text-blue-300">
                {preset.title}
              </p>
              <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                {preset.text}
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* Main Reporting Form */}
      <form onSubmit={handleSubmitReport} className="p-6 sm:p-8 rounded-2xl glass-panel space-y-6 border border-slate-800">
        {/* Description Field */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-bold text-slate-200">
              What is happening? Describe the issue *
            </label>
            <span className="text-[11px] text-slate-400">Natural plain English</span>
          </div>
          <textarea
            required
            rows={4}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="e.g. The staircase light near Block C has been broken for three days and it is very dark at night..."
            className="w-full px-4 py-3 rounded-xl glass-input text-xs leading-relaxed"
          />
        </div>

        {/* Location Field & Quick Pills */}
        <div>
          <label className="block text-xs font-bold text-slate-200 mb-1.5">
            Campus Location / Building / Room *
          </label>
          <div className="relative mb-2">
            <MapPin className="w-4 h-4 text-slate-400 absolute left-3.5 top-3 pointer-events-none" />
            <input
              type="text"
              required
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g. Block C - Staircase 2nd Floor, Central Library North Ramp..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl glass-input text-xs"
            />
          </div>

          <div className="flex flex-wrap items-center gap-1.5 pt-1">
            <span className="text-[11px] text-slate-400">Quick picks:</span>
            {quickLocations.map((loc, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setLocation(loc)}
                className="px-2 py-0.5 rounded-lg text-[10px] bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition"
              >
                {loc}
              </button>
            ))}
          </div>
        </div>

        {/* Category & Photo Upload */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-200 mb-1.5">
              Category (Optional — AI can detect)
            </label>
            <select
              value={optionalCategory}
              onChange={(e) => setOptionalCategory(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl glass-input text-xs"
            >
              <option value="">Let AI Automatically Detect</option>
              {categories.map((c) => (
                <option key={c} value={c} className="bg-slate-900 text-white">
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-200 mb-1.5">
              Photo / Attachment (Optional)
            </label>
            <div className="flex items-center gap-3">
              <label className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-dashed border-slate-700 hover:border-blue-500 bg-slate-900/50 cursor-pointer text-xs text-slate-300 transition">
                <Camera className="w-4 h-4 text-blue-400" />
                <span>{imagePreview ? 'Change Photo' : 'Upload Hazard Photo'}</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </label>
              {imagePreview && (
                <img
                  src={imagePreview}
                  alt="Preview"
                  className="w-10 h-10 object-cover rounded-lg border border-slate-700"
                />
              )}
            </div>
          </div>
        </div>

        {/* AI Triage Trigger Button */}
        <div className="p-4 rounded-xl bg-blue-950/20 border border-blue-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 text-xs text-slate-300">
            <Sparkles className="w-4 h-4 text-blue-400 flex-shrink-0" />
            <span>Click <strong>Analyze with AI</strong> to preview classification, urgency, and recommended department before filing.</span>
          </div>

          <button
            type="button"
            disabled={isAnalyzing || !description.trim()}
            onClick={handleAnalyzeWithAI}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition active:scale-95 ${
              isAnalyzing || !description.trim()
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md'
            }`}
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Analyzing...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5" />
                <span>Analyze with AI</span>
              </>
            )}
          </button>
        </div>

        {/* AI Analysis Preview Card */}
        {aiResult && (
          <div className="p-5 rounded-2xl bg-slate-950/90 border border-indigo-500/40 space-y-3 animate-fade-in text-xs">
            <div className="flex items-center justify-between">
              <span className="font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                <span>AI Preliminary Recommendation ({aiResult.confidence}% Confidence)</span>
              </span>
              <span className="text-[10px] text-slate-400">
                Engine: {aiResult.model || 'CampusGuardian AI Engine'}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
              <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-400 block">Category</span>
                <span className="font-bold text-white">{aiResult.category}</span>
              </div>
              <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                <span className="text-slate-400 block">Priority</span>
                <span className={`font-bold ${
                  aiResult.priority === 'Critical' ? 'text-rose-400' :
                  aiResult.priority === 'High' ? 'text-amber-400' :
                  aiResult.priority === 'Medium' ? 'text-blue-400' : 'text-slate-300'
                }`}>
                  {aiResult.priority}
                </span>
              </div>
              <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 sm:col-span-2">
                <span className="text-slate-400 block">Target Department</span>
                <span className="font-semibold text-slate-200 truncate block">{aiResult.department}</span>
              </div>
            </div>

            <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
              <span className="text-slate-400 block text-[10px] font-semibold">Triage Action Recommendation:</span>
              <p className="text-slate-200 mt-0.5">{aiResult.recommendedAction}</p>
            </div>

            <p className="text-[10px] text-slate-400 italic">
              * Note: AI outputs are automated decision recommendations. Campus dispatch will review and verify on-site.
            </p>
          </div>
        )}

        {/* Submit Button */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={isSubmitting}
            className={`w-full py-3.5 rounded-xl font-bold text-xs sm:text-sm text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 shadow-glow-blue transition active:scale-95 flex items-center justify-center gap-2 ${
              isSubmitting ? 'opacity-70 cursor-not-allowed' : ''
            }`}
          >
            {isSubmitting ? (
              <span>Saving to SQLite Database...</span>
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span>Submit Campus Incident Report</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
