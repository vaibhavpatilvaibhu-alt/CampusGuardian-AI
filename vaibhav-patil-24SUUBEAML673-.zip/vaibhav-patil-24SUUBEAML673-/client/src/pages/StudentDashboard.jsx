import React, { useState } from 'react';
import { useReports } from '../context/ReportsContext';
import { CAMPUS_ANNOUNCEMENTS } from '../data/initialReports';
import {
  FileText,
  Clock,
  AlertTriangle,
  CheckCircle,
  PlusCircle,
  Bot,
  PhoneCall,
  Accessibility,
  ArrowRight,
  MapPin,
  ChevronRight,
  ShieldCheck,
  Eye,
  Megaphone,
  Radio,
  LogOut,
  User,
  ShieldAlert,
  Sparkles
} from 'lucide-react';
import DisasterIndicatorBanner from '../components/DisasterIndicatorBanner';
import ThemeSelector from '../components/ThemeSelector';

export default function StudentDashboard() {
  const {
    reports,
    setActiveTab,
    currentUser,
    logout,
    activeAlerts
  } = useReports();

  const [selectedReport, setSelectedReport] = useState(null);

  // Computed metrics from real SQLite reports
  const totalReports = reports.length;
  const pendingReports = reports.filter(r => r.status !== 'Resolved' && r.status !== 'Closed').length;
  const criticalReports = reports.filter(r => r.priority === 'Critical').length;
  const resolvedReports = reports.filter(r => r.status === 'Resolved' || r.status === 'Closed').length;

  const recentReports = reports.slice(0, 5);

  const getPriorityBadge = (priority) => {
    switch (priority) {
      case 'Critical':
        return 'bg-rose-500/15 text-rose-400 border-rose-500/30';
      case 'High':
        return 'bg-amber-500/15 text-amber-400 border-amber-500/30';
      case 'Medium':
        return 'bg-blue-500/15 text-blue-400 border-blue-500/30';
      default:
        return 'bg-slate-500/15 text-slate-300 border-slate-500/30';
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Resolved':
      case 'Closed':
        return 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30';
      case 'In Progress':
        return 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30';
      case 'Assigned':
        return 'bg-indigo-500/15 text-indigo-400 border-indigo-500/30';
      case 'Under Review':
        return 'bg-amber-500/15 text-amber-400 border-amber-500/30';
      default:
        return 'bg-slate-500/15 text-slate-300 border-slate-500/30';
    }
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Active Disaster Indicator Banner */}
      <DisasterIndicatorBanner />

      {/* Welcome Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-navy-900 via-slate-900 to-indigo-950/60 border border-slate-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <ShieldCheck className="w-4 h-4" />
            </span>
            <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">
              Student Incident Portal • Authenticated Session
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            Welcome, {currentUser ? currentUser.name : 'Student Member'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl">
            Logged in as <code className="text-blue-300">{currentUser?.email || 'student@campusguardian.demo'}</code>. Track your submitted campus reports, view emergency advisories, or request assistance.
          </p>
        </div>

        {/* Quick Actions & Profile */}
        <div className="flex flex-wrap items-center gap-3">
          <ThemeSelector />

          <button
            onClick={() => setActiveTab('report')}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm shadow-glow-blue transition active:scale-95"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Report Campus Issue</span>
          </button>

          <button
            onClick={logout}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition border border-slate-800"
            title="Sign out of student account"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </div>

      {/* 4 Core Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Submitted */}
        <div className="p-5 rounded-2xl glass-panel relative overflow-hidden group">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-400">My Reports</span>
            <div className="p-2 rounded-xl bg-blue-500/10 text-blue-400 group-hover:scale-110 transition">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-bold text-white">{totalReports}</p>
          <p className="text-[11px] text-blue-400 mt-1">Stored in SQLite</p>
        </div>

        {/* Active / In Progress */}
        <div className="p-5 rounded-2xl glass-panel relative overflow-hidden group">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-400">In Progress</span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 group-hover:scale-110 transition">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-bold text-white">{pendingReports}</p>
          <p className="text-[11px] text-amber-400 mt-1">Under campus triage</p>
        </div>

        {/* Resolved */}
        <div className="p-5 rounded-2xl glass-panel relative overflow-hidden group">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-400">Resolved</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 group-hover:scale-110 transition">
              <CheckCircle className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-bold text-white">{resolvedReports}</p>
          <p className="text-[11px] text-emerald-400 mt-1">Completed repairs</p>
        </div>

        {/* Disaster Alerts Indicator */}
        <div className="p-5 rounded-2xl glass-panel relative overflow-hidden group cursor-pointer" onClick={() => setActiveTab('disaster-indicator')}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-slate-400">Disaster Alerts</span>
            <div className="p-2 rounded-xl bg-rose-500/10 text-rose-400 group-hover:scale-110 transition">
              <Radio className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-bold text-white">{activeAlerts.length}</p>
          <p className="text-[11px] text-rose-400 mt-1">Active broadcast notices</p>
        </div>
      </div>

      {/* Main Grid: My Recent Reports & Campus Safety Hub */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: My Recent Reports (2 cols) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <FileText className="w-4 h-4 text-blue-400" />
              <span>My Submitted Reports ({reports.length})</span>
            </h2>

            <button
              onClick={() => setActiveTab('my-reports')}
              className="text-xs font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1"
            >
              <span>View All Reports</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {recentReports.length > 0 ? (
            <div className="space-y-3">
              {recentReports.map((report) => (
                <div
                  key={report.id}
                  onClick={() => setSelectedReport(report)}
                  className="p-4 sm:p-5 rounded-2xl glass-panel-interactive cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-4 group"
                >
                  <div className="space-y-1.5 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-slate-300">
                        {report.id}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${getPriorityBadge(report.priority)}`}>
                        {report.priority}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${getStatusBadge(report.status)}`}>
                        {report.status}
                      </span>
                      <span className="text-[11px] text-slate-400">
                        Category: {report.category}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-white group-hover:text-blue-300 transition-colors">
                      {report.summary || report.title || report.description}
                    </h3>

                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      <MapPin className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />
                      <span>{report.location}</span>
                      <span>•</span>
                      <span>{new Date(report.created_at).toLocaleDateString()}</span>
                    </div>

                    {report.admin_notes && (
                      <p className="text-[11px] text-blue-300 bg-blue-950/40 px-2 py-1 rounded border border-blue-800/40">
                        <strong>Admin Note:</strong> {report.admin_notes}
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-2 flex-shrink-0 self-end sm:self-center">
                    <span className="text-xs text-slate-400 group-hover:text-white flex items-center gap-1 font-medium">
                      <span>Timeline</span>
                      <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition" />
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 rounded-2xl glass-panel text-center">
              <div className="w-12 h-12 rounded-full bg-blue-500/10 text-blue-400 flex items-center justify-center mx-auto mb-3">
                <FileText className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white">No Submitted Reports</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1 mb-4">
                You haven't submitted any campus reports yet. Report hazards, lighting, or repairs easily.
              </p>
              <button
                onClick={() => setActiveTab('report')}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-500"
              >
                Submit Your First Report
              </button>
            </div>
          )}
        </div>

        {/* Right Column: Campus Announcements & Safety Shortcuts (1 col) */}
        <div className="space-y-6">
          {/* Quick Hub Cards */}
          <div className="p-5 rounded-2xl glass-panel space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span>Campus Safety Quick Access</span>
            </h3>

            <div className="space-y-2 text-xs">
              <button
                onClick={() => setActiveTab('disaster-indicator')}
                className="w-full p-2.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-700/60 flex items-center justify-between text-left text-slate-200 transition"
              >
                <div className="flex items-center gap-2">
                  <Radio className="w-4 h-4 text-rose-400" />
                  <span>Disaster Indicator Hub</span>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>

              <button
                onClick={() => setActiveTab('assistant')}
                className="w-full p-2.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-700/60 flex items-center justify-between text-left text-slate-200 transition"
              >
                <div className="flex items-center gap-2">
                  <Bot className="w-4 h-4 text-indigo-400" />
                  <span>GuardianBot AI Assistant</span>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>

              <button
                onClick={() => setActiveTab('emergency')}
                className="w-full p-2.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-700/60 flex items-center justify-between text-left text-slate-200 transition"
              >
                <div className="flex items-center gap-2">
                  <PhoneCall className="w-4 h-4 text-rose-400" />
                  <span>Emergency Hotlines & SOS</span>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>

              <button
                onClick={() => setActiveTab('accessibility')}
                className="w-full p-2.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-700/60 flex items-center justify-between text-left text-slate-200 transition"
              >
                <div className="flex items-center gap-2">
                  <Accessibility className="w-4 h-4 text-emerald-400" />
                  <span>Accessibility Resources</span>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>
            </div>
          </div>

          {/* Campus Announcements */}
          <div className="p-5 rounded-2xl glass-panel space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Megaphone className="w-4 h-4 text-amber-400" />
              <span>Campus Safety Bulletins</span>
            </h3>

            <div className="space-y-3">
              {CAMPUS_ANNOUNCEMENTS.slice(0, 3).map((item) => (
                <div key={item.id} className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-200">{item.title}</span>
                    <span className="text-[10px] text-slate-400">{item.date}</span>
                  </div>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    {item.message}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Report Details Drawer / Modal */}
      {selectedReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-navy-950/80 backdrop-blur-md">
          <div className="w-full max-w-lg rounded-2xl glass-panel bg-slate-900 border border-slate-700 p-6 space-y-4 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold px-2 py-0.5 rounded bg-blue-500/20 text-blue-300">
                {selectedReport.id}
              </span>
              <button
                onClick={() => setSelectedReport(null)}
                className="p-1 rounded text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <h3 className="text-base font-bold text-white">
              {selectedReport.title || selectedReport.summary}
            </h3>

            <div className="space-y-2 text-xs text-slate-300">
              <p><strong>Description:</strong> {selectedReport.description}</p>
              <p><strong>Location:</strong> {selectedReport.location}</p>
              <p><strong>Category:</strong> {selectedReport.category}</p>
              <p><strong>Department:</strong> {selectedReport.department}</p>
              <p><strong>Status:</strong> <span className="font-bold text-blue-400">{selectedReport.status}</span></p>
              {selectedReport.admin_notes && (
                <div className="p-3 rounded-lg bg-blue-950/50 border border-blue-800 text-blue-200">
                  <strong>Administrative Update:</strong> {selectedReport.admin_notes}
                </div>
              )}
              {selectedReport.resolution_details && (
                <div className="p-3 rounded-lg bg-emerald-950/50 border border-emerald-800 text-emerald-200">
                  <strong>Resolution Details:</strong> {selectedReport.resolution_details}
                </div>
              )}
            </div>

            {/* Timeline */}
            <div className="pt-3 border-t border-slate-800 space-y-2">
              <h4 className="text-xs font-bold text-slate-200">Incident Activity Timeline:</h4>
              <div className="space-y-2">
                {selectedReport.timeline?.map((step, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-[11px]">
                    <div className="w-2 h-2 rounded-full bg-blue-400 mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-slate-200">{step.status} — <span className="text-slate-400">{new Date(step.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span></p>
                      <p className="text-slate-400">{step.note}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
