import React, { useState, useEffect } from 'react';
import { useReports } from '../context/ReportsContext';
import {
  Shield,
  GraduationCap,
  KeyRound,
  X,
  Lock,
  Mail,
  Eye,
  EyeOff,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export default function AuthModal() {
  const {
    authModalOpen,
    authModalDefaultRole,
    closeAuthModal,
    login
  } = useReports();

  const [activeRole, setActiveRole] = useState('student');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Sync role when modal opens
  useEffect(() => {
    if (authModalOpen) {
      setActiveRole(authModalDefaultRole || 'student');
      setErrorMsg('');
      if (authModalDefaultRole === 'admin') {
        setEmail('admin@campusguardian.demo');
        setPassword('admin123');
      } else {
        setEmail('student@campusguardian.demo');
        setPassword('student123');
      }
    }
  }, [authModalOpen, authModalDefaultRole]);

  if (!authModalOpen) return null;

  const handleSelectRole = (role) => {
    setActiveRole(role);
    setErrorMsg('');
    if (role === 'admin') {
      setEmail('admin@campusguardian.demo');
      setPassword('admin123');
    } else {
      setEmail('student@campusguardian.demo');
      setPassword('student123');
    }
  };

  const handleFillDemo = (role) => {
    setActiveRole(role);
    setErrorMsg('');
    if (role === 'admin') {
      setEmail('admin@campusguardian.demo');
      setPassword('admin123');
    } else {
      setEmail('student@campusguardian.demo');
      setPassword('student123');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg('');

    if (!email.trim() || !password.trim()) {
      setErrorMsg('Please enter both email and password.');
      return;
    }

    setIsLoading(true);
    try {
      await login(email.trim(), password.trim());
      closeAuthModal();
    } catch (err) {
      setErrorMsg(err.message || 'Login failed. Please check credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-navy-950/80 backdrop-blur-md animate-fade-in">
      <div
        className="relative w-full max-w-md rounded-2xl glass-panel bg-slate-900/95 border border-slate-700/80 p-6 sm:p-8 shadow-2xl text-slate-100"
        role="dialog"
        aria-modal="true"
        aria-labelledby="auth-modal-title"
      >
        {/* Close Button */}
        <button
          onClick={closeAuthModal}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/80 transition"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600 flex items-center justify-center shadow-glow-blue flex-shrink-0">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 id="auth-modal-title" className="text-xl font-bold tracking-tight text-white">
              CampusGuardian AI
            </h2>
            <p className="text-xs text-slate-400">
              "A Safer Campus. A Smarter Response."
            </p>
          </div>
        </div>

        {/* Role Tabs */}
        <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-slate-950/80 border border-slate-800 mb-6">
          <button
            type="button"
            onClick={() => handleSelectRole('student')}
            className={`flex items-center justify-center gap-2 py-2.5 rounded-lg text-xs font-semibold transition ${
              activeRole === 'student'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <GraduationCap className="w-4 h-4" />
            <span>Student Portal</span>
          </button>

          <button
            type="button"
            onClick={() => handleSelectRole('admin')}
            className={`flex items-center justify-center gap-2 py-2.5 rounded-lg text-xs font-semibold transition ${
              activeRole === 'admin'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <KeyRound className="w-4 h-4" />
            <span>Administration</span>
          </button>
        </div>

        {/* One-Click Demo Shortcut */}
        <div className="mb-5 p-3 rounded-xl bg-slate-950/50 border border-slate-800/80 text-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="font-semibold text-slate-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Hackathon Quick-Test Credentials</span>
            </span>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => handleFillDemo('student')}
              className={`flex-1 py-1.5 px-2 rounded-lg text-[11px] font-medium border text-center transition ${
                activeRole === 'student'
                  ? 'bg-blue-500/10 border-blue-500/40 text-blue-300 hover:bg-blue-500/20'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              Fill Demo Student
            </button>
            <button
              type="button"
              onClick={() => handleFillDemo('admin')}
              className={`flex-1 py-1.5 px-2 rounded-lg text-[11px] font-medium border text-center transition ${
                activeRole === 'admin'
                  ? 'bg-purple-500/10 border-purple-500/40 text-purple-300 hover:bg-purple-500/20'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              Fill Demo Admin
            </button>
          </div>
        </div>

        {/* Error Alert */}
        {errorMsg && (
          <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={activeRole === 'admin' ? 'admin@campusguardian.demo' : 'student@campusguardian.demo'}
                className="w-full pl-9 pr-3 py-2.5 rounded-xl glass-input text-xs"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-10 py-2.5 rounded-xl glass-input text-xs"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-200"
                tabIndex={-1}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={isLoading}
              className={`w-full py-3 rounded-xl font-semibold text-xs text-white shadow-glow-blue transition active:scale-95 flex items-center justify-center gap-2 ${
                activeRole === 'admin'
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500'
                  : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500'
              } ${isLoading ? 'opacity-70 cursor-not-allowed' : ''}`}
            >
              {isLoading ? (
                <span>Authenticating with SQLite...</span>
              ) : (
                <>
                  <span>Sign In as {activeRole === 'admin' ? 'Administrator' : 'Student'}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </form>

        {/* Security Policy Notice */}
        <div className="mt-5 pt-4 border-t border-slate-800 text-[11px] text-slate-400 text-center">
          <p>
            🔒 <strong className="text-slate-300">Session Security:</strong> Sessions are cryptographically verified by the backend. Passwords are never stored in localStorage.
          </p>
        </div>
      </div>
    </div>
  );
}
